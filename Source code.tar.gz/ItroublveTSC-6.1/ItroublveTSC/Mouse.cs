﻿using System.Drawing;

namespace ItroublveTSC
{
    internal class Mouse
    {
        public static Point newpoint = default(Point);

        public static int x;

        public static int y;
    }
}
