﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("ItroublveTSC")]
[assembly: AssemblyDescription("Based on ByteToolsTSC")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ItroublveTSC")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("a1026a85-361c-4a03-8a4d-6df707a20e86")]
[assembly: AssemblyFileVersion("1.0.0.0")]
