# Token-Browser-Password-Stealer-Creator

This is a discord token stealer and a browser password stealer.
This is really easy to use and I hope this will only be used for educational purposes and not to harm anyone or threat anyone!


The tool it self is really easy to use. The compiled and released version can be found in "Releases". 

Also I must give credit to "ByteTools" for their OPEN SOURCE tool and permission to use their DLL and Design. 
THIS IS AN EARLY RELEASE SO THERE MIGHT BE SOME ISSUES IN CODE!
Good Luck, hope you enjoy the tool... 

Please do not copy and advertise this as your own work. You are free to use this and modify as long as you give credit to me and ByteTools.
THANKS ;)
